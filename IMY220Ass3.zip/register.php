<!DOCTYPE html>
<html>

    <head>
        <title>IMY220 - Assignment 3</title>
        <meta charset="utf-8" />
        <meta name="author" content="Paul Mouton">
        <!-- Replace Name Surname with your name and surname -->

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>

    <body>
        <?php
            $servername = "localhost";
            $username = "root";
            $pass = "";
            $dbname = "dbUser";
            $conn = mysqli_connect($servername, $username, $pass, $dbname);
            mysqli_select_db($conn,"dbUser");
            
            if(!$conn){
            ?>
                <div class="alert alert-danger">
                    The connection to the database could not be made
                </div>
            <?php

            }else{
                $Name = $_POST["regName"];
                $Surname = $_POST["regSurname"];
                $password1 = $_POST["pass1"];
                $password2 = $_POST["pass2"];
                $email = $_POST["regEmail"];
                $birthday = $_POST["regBirthDate"];

                if($password1 == $password2){
                    $Statement = "INSERT INTO `tbUsers` (`name`, `surname`, `password`, `email`, `birthday`) VALUES ('$Name', '$Surname', '$password1', '$email', '$birthday')";
                    
                    if (mysqli_query($conn, $Statement)) {
                    ?>
                        <div class="alert alert-info">
                            The account has been created
                        </div>
                    <?php
                    } else {
                    ?>
                        <div class="alert alert-danger">
                            The SQL query failed to execute
                        </div>
                    <?php
                    }

                }else{
                ?>
                    <div class="alert alert-danger">
                        The passwords do not match
                    </div>
                <?php
                }

                mysqli_close($conn);
            }
        ?>

        
    </body>
</html>