<!DOCTYPE html>
<html>

    <head>
        <title>IMY220 - Assignment 3</title>
        <meta charset="utf-8" />
        <meta name="author" content="Paul Mouton">
        <!-- Replace Name Surname with your name and surname -->

        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
        <link rel="stylesheet" type="text/css" href="style.css" />
    </head>

    <body>
        <?php
            $servername = "localhost";
            $username = "root";
            $pass = "";
            $dbname = "dbUser";
            $conn = mysqli_connect($servername, $username, $pass, $dbname);
            mysqli_select_db($conn,"dbUser");
            
            if(!$conn){
            ?>
                <div class="alert alert-danger">
                    The connection to the database could not be made
                </div>
            <?php

            }else{
                $pass = $_POST["loginPassw"];
                $email = $_POST["loginName"];

                $Statement = "SELECT * FROM `tbUsers` WHERE `email` = '$email'";

                $result = mysqli_query($conn,$Statement);

                if (!(mysqli_num_rows($result) > 0)){
                ?>
                    <div class="alert alert-danger">
                        You are not registered on this site!
                    </div>
                <?php
                }else{
                    $Wadu = $result->fetch_assoc();
                    $RealPassword = $Wadu["password"];
                    $RealName = $Wadu["name"];
                    $RealSurname = $Wadu["surname"];
                    $RealEmail = $Wadu["email"];
                    $RealBirthday = $Wadu["birthday"];
                    $userid = $Wadu["user_id"];

                    if($pass == $RealPassword){
                    ?>
                        <table class="table-bordered">
                            <tr>
                                <td>Name</td>
                                <td>
                                    <?php echo $RealName ?>
                                </td>
                            </tr>

                            <tr>
                                <td>Surname</td>
                                <td>
                                    <?php echo $RealSurname ?>
                                </td>
                            </tr>

                            <tr>
                                <td>Email Address</td>
                                <td>
                                    <?php echo $RealEmail ?>
                                </td>
                            </tr>

                            <tr>
                                <td>Birthday</td>
                                <td>
                                    <?php echo $RealBirthday ?>
                                </td>
                            </tr>

                        </table>
                        <form action="login.php" method="POST" enctype="multipart/form-data">
                            <input type="file" name="fileToUpload" id="fileToUpload"/>
                            <input type="submit" value="Upload Image" name="submit"/>
                            <input type="hidden" name="loginName" value=<?php echo $email?>>
                            <input type="hidden" name="loginPassw" value=<?php echo $pass?>>
                        </form>

                        <?php
                        if(isset($_POST["submit"])){
                            $uploadFile = $_FILES["fileToUpload"];
                            $LeName = $uploadFile["name"];
                            $target_dir = "gallery/";
                            $target_file = $target_dir . basename($uploadFile["name"]);
                            $imageFileType = pathinfo($target_file, PATHINFO_EXTENSION);
                            if (($uploadFile["type"] == "image/jpeg") && $uploadFile["size"] < 1000000){
                                if(move_uploaded_file($uploadFile["tmp_name"], $target_file)){
                                    $Statement = "INSERT INTO `tbgallery` (`user_id`, `filename`) VALUES ('$userid', '$LeName')";
                                    if (mysqli_query($conn, $Statement)) {
                                        echo "Successfully uploaded";
                                    }
                                    else{
                                        echo "Could not add file to database";
                                    }
                                    
                                }else   
                                    echo "File upload failed";
                            }
                            
                        }
                        ?>
                        <h1>Image Gallery</h1>
                        <div class="row imageGallery">
                        <?php

                            $Statement = "SELECT * FROM `tbgallery` WHERE `user_id` = '$userid'";
                            $result = mysqli_query($conn,$Statement);
                            if (!(mysqli_num_rows($result) > 0)){
                                echo "Here Bro";
                                for($i = 0; $i < mysqli_num_rows($result); $i++){
                                    $Wadu = $result[$i]->fetch_assoc();
                                    $Picname = $Wadu["filename"];
                                    echo $Picname;                                    ?>
                                        <div class="col-3" style="background-image: url(gallery/" <?php echo "$Picname" . ")"?> >
                                    <?php
                                }
                            }
                        ?>
                        </div>
                    <?php
                    }else{
                    ?>
                        <div class="alert alert-danger">
                            You are not registered on this site!
                        </div>
                    <?php 
                    }
                }

                
                mysqli_close($conn);
            }
        ?>

        
    </body>
</html>